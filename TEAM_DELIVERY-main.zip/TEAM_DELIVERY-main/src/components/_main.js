import './base/base';
import './basket/basket';
import './cards/cards';
import './food_cards/food_cards';
import './footer/footer';
import './header/header';
import './map/map';